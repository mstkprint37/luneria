# Lunéria

Application Expo / React Native de génération infinie d'histoires pour enfants.

## Fonctions
- Générateur infini d'histoires
- Plusieurs enfants + âges
- Thèmes
- Durées 10 / 20 / 30-50 min
- Lecture vocale avec expo-speech
- Bibliothèque de sauvegarde en session
- NFC simulé pour Snack

## Installation

```bash
npm install
npm start
```

## Important
Le NFC est simulé dans cette version. Le vrai NFC demandera une build native avec `react-native-nfc-manager`.
