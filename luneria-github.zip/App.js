import React, { useState } from "react";
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";
import * as Speech from "expo-speech";

const THEMES = [
  { label: "Dragon", emoji: "🐉" },
  { label: "Espace", emoji: "🚀" },
  { label: "Licorne", emoji: "🦄" },
  { label: "Dino", emoji: "🦖" },
  { label: "Pirate", emoji: "🏴‍☠️" },
  { label: "Sirène", emoji: "🧜‍♀️" },
  { label: "Robot", emoji: "🤖" },
  { label: "Noël", emoji: "🎄" },
  { label: "Fée", emoji: "🧚" },
  { label: "Océan", emoji: "🌊" },
  { label: "Safari", emoji: "🦁" },
  { label: "Super-héros", emoji: "🦸" },
  { label: "École magique", emoji: "🏫" },
  { label: "Voyage temps", emoji: "⏳" },
  { label: "Monstres gentils", emoji: "👾" },
  { label: "Forêt magique", emoji: "🌲" }
];

const DATA = {
  intros: [
    "Une lumière dorée apparut soudain dans la chambre.",
    "La lune se mit à briller plus fort que d’habitude.",
    "Une étoile tomba doucement devant la fenêtre.",
    "Un petit portail violet s’ouvrit au milieu de la pièce.",
    "Un livre magique se mit à tourner ses pages tout seul.",
    "Une bulle lumineuse descendit du plafond.",
    "Le doudou posé sur le lit cligna des yeux et sourit.",
    "Un rayon de lune dessina une porte secrète."
  ],
  lieux: [
    "la forêt des étoiles",
    "le château des nuages",
    "l’île des dragons doux",
    "la planète des rêves bleus",
    "la montagne de cristal",
    "la bibliothèque de la lune",
    "le village des lanternes magiques",
    "l’océan des coquillages chantants",
    "la vallée des licornes",
    "la cité secrète des robots gentils",
    "le royaume des dinosaures rigolos"
  ],
  compagnons: [
    "un petit dragon bleu",
    "une licorne timide",
    "un robot au cœur lumineux",
    "une fée brillante",
    "un hibou lunaire",
    "un bébé dinosaure rigolo",
    "un renard étoilé",
    "un chat astronaute",
    "une sirène chanteuse"
  ],
  objets: [
    "une pierre lunaire",
    "une clé dorée",
    "une boussole des rêves",
    "une lanterne magique",
    "une plume arc-en-ciel",
    "un livre qui écrivait tout seul"
  ],
  missions: [
    "retrouver une étoile disparue",
    "réveiller la lune endormie",
    "sauver les rêves des enfants",
    "retrouver les couleurs du ciel",
    "réparer le phare des étoiles",
    "ouvrir la porte magique"
  ],
  dangers: [
    "une tempête de poussière d’étoiles",
    "un brouillard violet",
    "une rivière d’ombres",
    "un labyrinthe de nuages",
    "un pont invisible",
    "un vent qui mélangeait tous les chemins"
  ],
  rebondissements: [
    "une porte secrète apparut dans un arbre",
    "une étoile se mit à parler",
    "le ciel changea soudainement de couleur",
    "la lune révéla un message argenté",
    "un ancien livre se réveilla",
    "une chanson mystérieuse guida les enfants"
  ],
  fins: [
    "les étoiles brillèrent à nouveau",
    "la lune retrouva son sourire",
    "le royaume magique s’illumina",
    "les rêves revinrent dans le ciel",
    "la magie revint dans tout Lunéria"
  ],
  morales: [
    "le courage est une petite lumière qui grandit quand on avance",
    "l’amitié est une vraie magie",
    "chaque enfant possède une force unique",
    "les rêves deviennent plus grands quand on les partage",
    "la gentillesse peut changer le monde"
  ],
  titres: [
    "Le secret de Lunéria",
    "La lune oubliée",
    "Le portail des rêves",
    "L’étoile perdue",
    "La forêt magique",
    "Le royaume caché"
  ]
};

function choisir(liste) {
  return liste[Math.floor(Math.random() * liste.length)];
}

export default function App() {
  const [enfants, setEnfants] = useState([{ prenom: "", age: "" }]);
  const [theme, setTheme] = useState("Dragon");
  const [duree, setDuree] = useState("30-50 min");
  const [histoire, setHistoire] = useState(
    "Bienvenue dans Lunéria. Appuie sur Générer pour créer une histoire infinie."
  );
  const [saved, setSaved] = useState([]);
  const [lecture, setLecture] = useState(false);
  const [nfcId, setNfcId] = useState("");
  const [nfcStories, setNfcStories] = useState({});

  function modifierEnfant(index, champ, valeur) {
    const copie = [...enfants];
    copie[index][champ] = valeur;
    setEnfants(copie);
  }

  function ajouterEnfant() {
    setEnfants([...enfants, { prenom: "", age: "" }]);
  }

  function supprimerEnfant(index) {
    if (enfants.length === 1) return;
    setEnfants(enfants.filter((_, i) => i !== index));
  }

  function creerHistoire(idPuce = "") {
    const heros = enfants.filter((e) => e.prenom.trim() !== "");
    const listeHeros = heros.length > 0 ? heros : [{ prenom: "Lina", age: "6" }];

    const noms = listeHeros
      .map((e) => `${e.prenom || "Lina"} (${e.age || "6"} ans)`)
      .join(" et ");

    const nomsSimples = listeHeros
      .map((e) => e.prenom || "Lina")
      .join(" et ");

    let texte = `Titre — ${choisir(DATA.titres)}

Chapitre 1 — L’appel magique

Il était une fois ${noms}.

${choisir(DATA.intros)}

${idPuce ? `La puce NFC ${idPuce} vibra doucement et réveilla une histoire cachée.` : "Une lumière magique apparut et ouvrit une porte vers Lunéria."}

Les enfants traversèrent le portail et arrivèrent dans ${choisir(DATA.lieux)}.

Le thème de cette aventure était : ${theme}.

Chapitre 2 — Le compagnon

Au milieu du chemin, ils rencontrèrent ${choisir(DATA.compagnons)}.

Leur mission : ${choisir(DATA.missions)}.

Pour les aider, ils reçurent ${choisir(DATA.objets)}.

Chapitre 3 — Le chemin des rêves

${nomsSimples} avancèrent ensemble. Ils traversèrent des ponts suspendus, des rivières lumineuses et des arbres qui murmuraient des secrets.

Mais soudain, ils durent affronter ${choisir(DATA.dangers)}.

Chapitre 4 — Le rebondissement

Alors que tout semblait perdu, ${choisir(DATA.rebondissements)}.

Les enfants comprirent que la vraie magie venait de leur courage et de leur amitié.

Chapitre final — La magie retrouvée

Grâce à eux, ${choisir(DATA.fins)}.

Depuis ce jour, ${nomsSimples} n’oublièrent jamais que ${choisir(DATA.morales)}.`;

    if (duree === "20 min" || duree === "30-50 min") {
      texte += `

Chapitre bonus — Le livre secret

Avant de rentrer, les enfants découvrirent une bibliothèque cachée dans les nuages.

Chaque livre racontait une aventure différente.

Une phrase apparut : « Votre histoire ne fait que commencer. »`;
    }

    if (duree === "30-50 min") {
      texte += `

Chapitre secret — L’aventure continue

La petite étoile qui les guidait montra un nouveau chemin vers une montagne argentée.

Au sommet, les enfants trouvèrent une étoile endormie. Ils lui parlèrent doucement, lui racontèrent leur aventure et leur courage.

Peu à peu, l’étoile ouvrit les yeux et illumina tout le ciel.

Épilogue

Chaque nuit, elle rappelait qu’une nouvelle aventure pouvait commencer à tout moment.`;
    }

    return texte;
  }

  function genererHistoire(idPuce = "") {
    const texte = creerHistoire(idPuce);
    setHistoire(texte);
    return texte;
  }

  function scannerNFC() {
    const fakeId = "NFC-" + Math.floor(Math.random() * 999999);
    setNfcId(fakeId);

    if (nfcStories[fakeId]) {
      setHistoire(nfcStories[fakeId]);
      Alert.alert("Puce NFC reconnue", fakeId);
    } else {
      genererHistoire(fakeId);
      Alert.alert("Nouvelle puce NFC simulée", fakeId);
    }
  }

  function associerNFC() {
    if (!nfcId) {
      Alert.alert("Aucune puce", "Scanne une puce NFC avant d’associer l’histoire.");
      return;
    }

    setNfcStories({ ...nfcStories, [nfcId]: histoire });
    Alert.alert("Associé", "Cette puce lancera maintenant cette histoire.");
  }

  function lireHistoire() {
    Speech.stop();
    setLecture(true);

    Speech.speak(histoire, {
      language: "fr-FR",
      rate: 0.92,
      pitch: 1,
      volume: 1,
      useApplicationAudioSession: true,
      onDone: () => setLecture(false),
      onStopped: () => setLecture(false),
      onError: () => setLecture(false)
    });
  }

  function stopHistoire() {
    Speech.stop();
    setLecture(false);
  }

  function sauverHistoire() {
    setSaved([{ id: Date.now(), text: histoire, date: new Date().toLocaleString() }, ...saved]);
    Alert.alert("Sauvegardé", "Histoire sauvegardée.");
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.moon} />
      <Text style={styles.starA}>✦</Text>
      <Text style={styles.starB}>✧</Text>
      <Text style={styles.starC}>★</Text>

      <Text style={styles.title}>☾ Lunéria</Text>
      <Text style={styles.subtitle}>Générateur infini d’histoires magiques.</Text>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>📡 NFC simulé</Text>
        <TouchableOpacity style={styles.nfcButton} onPress={scannerNFC}>
          <Text style={styles.buttonText}>Scanner une puce NFC</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.saveButton} onPress={associerNFC}>
          <Text style={styles.buttonText}>Associer cette histoire</Text>
        </TouchableOpacity>
        <Text style={styles.info}>Dernière puce : {nfcId || "Aucune"}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>👨‍👩‍👧‍👦 Enfants</Text>
        {enfants.map((enfant, index) => (
          <View key={index} style={styles.childRow}>
            <TextInput
              style={[styles.input, styles.childNameInput]}
              placeholder={`Prénom ${index + 1}`}
              placeholderTextColor="#DDD"
              value={enfant.prenom}
              onChangeText={(v) => modifierEnfant(index, "prenom", v)}
            />
            <TextInput
              style={[styles.input, styles.ageInput]}
              placeholder="Âge"
              placeholderTextColor="#DDD"
              keyboardType="number-pad"
              value={enfant.age}
              onChangeText={(v) => modifierEnfant(index, "age", v)}
            />
            <TouchableOpacity style={styles.deleteButton} onPress={() => supprimerEnfant(index)}>
              <Text style={styles.buttonText}>✕</Text>
            </TouchableOpacity>
          </View>
        ))}
        <TouchableOpacity style={styles.addButton} onPress={ajouterEnfant}>
          <Text style={styles.buttonText}>Ajouter un enfant</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>⭐ Thèmes</Text>
        <View style={styles.themeGrid}>
          {THEMES.map((t) => (
            <TouchableOpacity
              key={t.label}
              style={[styles.themeCard, theme === t.label && styles.activeTheme]}
              onPress={() => setTheme(t.label)}
            >
              <Text style={styles.themeEmoji}>{t.emoji}</Text>
              <Text style={styles.themeText}>{t.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>⏱️ Durée</Text>
        <View style={styles.row}>
          {["10 min", "20 min", "30-50 min"].map((d) => (
            <TouchableOpacity key={d} style={[styles.chip, duree === d && styles.activeChip]} onPress={() => setDuree(d)}>
              <Text style={styles.chipText}>{d}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <TouchableOpacity style={styles.generateButton} onPress={() => genererHistoire()}>
        <Text style={styles.generateText}>✨ Générer une histoire infinie</Text>
      </TouchableOpacity>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🎧 Lecture</Text>
        <View style={styles.playerRow}>
          <TouchableOpacity style={styles.playButton} onPress={lireHistoire}>
            <Text style={styles.buttonText}>Lire</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.stopButton} onPress={stopHistoire}>
            <Text style={styles.buttonText}>Stop</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.saveButton} onPress={sauverHistoire}>
            <Text style={styles.buttonText}>Sauver</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.status}>{lecture ? "⭐ Lecture en cours..." : "⭐ Prêt à lire"}</Text>
      </View>

      <View style={styles.storyBox}>
        <Text style={styles.story}>{histoire}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>📚 Bibliothèque</Text>
        {saved.length === 0 ? (
          <Text style={styles.emptyText}>Aucune histoire sauvegardée.</Text>
        ) : (
          saved.map((item, index) => (
            <TouchableOpacity key={item.id} style={styles.saved} onPress={() => setHistoire(item.text)}>
              <Text style={styles.savedText}>Histoire sauvegardée {index + 1}</Text>
              <Text style={styles.savedDate}>{item.date}</Text>
            </TouchableOpacity>
          ))
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#120A3D" },
  content: { padding: 20, paddingBottom: 60 },
  moon: { position: "absolute", top: 30, left: 20, width: 90, height: 90, borderRadius: 45, backgroundColor: "#FDE68A" },
  starA: { position: "absolute", right: 30, top: 30, color: "#FDE68A", fontSize: 26 },
  starB: { position: "absolute", left: 50, top: 190, color: "white", fontSize: 18 },
  starC: { position: "absolute", right: 70, top: 270, color: "#FDE68A", fontSize: 18 },
  title: { color: "#FFE7A3", fontSize: 46, fontWeight: "bold", textAlign: "center", marginTop: 40 },
  subtitle: { color: "white", textAlign: "center", marginBottom: 30, fontSize: 17 },
  section: { backgroundColor: "rgba(70,50,160,0.5)", padding: 18, borderRadius: 20, marginBottom: 16, borderWidth: 1, borderColor: "rgba(255,255,255,0.18)" },
  sectionTitle: { color: "white", fontSize: 20, fontWeight: "bold", marginBottom: 14 },
  input: { backgroundColor: "rgba(255,255,255,0.12)", color: "white", padding: 14, borderRadius: 16, marginBottom: 10, fontSize: 16, borderWidth: 1, borderColor: "rgba(255,255,255,0.18)" },
  childRow: { flexDirection: "row", gap: 8, alignItems: "center", marginBottom: 8 },
  childNameInput: { flex: 1.4 },
  ageInput: { flex: 0.7 },
  deleteButton: { backgroundColor: "#DC2626", padding: 12, borderRadius: 14, marginBottom: 10 },
  addButton: { backgroundColor: "#B13DFF", padding: 16, borderRadius: 16, alignItems: "center" },
  nfcButton: { backgroundColor: "#F59E0B", padding: 16, borderRadius: 16, alignItems: "center", marginBottom: 10 },
  saveButton: { backgroundColor: "#16A34A", padding: 14, borderRadius: 16, alignItems: "center" },
  buttonText: { color: "white", fontWeight: "bold", fontSize: 15 },
  info: { color: "#FDE68A", fontWeight: "bold", marginTop: 10 },
  themeGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  themeCard: { width: "47%", backgroundColor: "rgba(30,20,100,0.7)", padding: 14, borderRadius: 16, alignItems: "center" },
  activeTheme: { borderWidth: 2, borderColor: "#FDE68A" },
  themeEmoji: { fontSize: 34, marginBottom: 6 },
  themeText: { color: "white", fontWeight: "bold", textAlign: "center" },
  row: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  chip: { backgroundColor: "rgba(255,255,255,0.12)", padding: 14, borderRadius: 18 },
  activeChip: { borderWidth: 2, borderColor: "#FDE68A" },
  chipText: { color: "white", fontWeight: "bold" },
  generateButton: { backgroundColor: "#B13DFF", padding: 20, borderRadius: 18, alignItems: "center", marginBottom: 18 },
  generateText: { color: "white", fontSize: 18, fontWeight: "bold" },
  playerRow: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 10 },
  playButton: { backgroundColor: "#5B3DF5", padding: 14, borderRadius: 16 },
  stopButton: { backgroundColor: "#DC2626", padding: 14, borderRadius: 16 },
  status: { color: "#FDE68A", fontWeight: "bold" },
  storyBox: { backgroundColor: "#FFF7ED", borderRadius: 20, padding: 20, marginBottom: 20 },
  story: { color: "#11145A", fontSize: 18, lineHeight: 30 },
  emptyText: { color: "rgba(255,255,255,0.75)" },
  saved: { backgroundColor: "rgba(255,255,255,0.14)", padding: 15, borderRadius: 14, marginTop: 10 },
  savedText: { color: "white", fontWeight: "bold" },
  savedDate: { color: "rgba(255,255,255,0.65)", marginTop: 4 }
});